document.addEventListener("DOMContentLoaded", function() {
    const changeColorBtn = document.getElementById("changeColorBtn");
    const fetchDataBtn = document.getElementById("fetchDataBtn");
    const dataContainer = document.getElementById("dataContainer");
    const contactForm = document.getElementById("contactForm");

    // Change background color
    changeColorBtn.addEventListener("click", function() {
        document.body.classList.toggle("bg-custom");
    });

    // Fetch and display API data
    fetchDataBtn.addEventListener("click", function() {
        fetch("https://jsonplaceholder.typicode.com/posts?_limit=3")
            .then(response => response.json())
            .then(data => {
                dataContainer.innerHTML = data.map(post => `
                    <div class="card my-2 p-3">
                        <h5>${post.title}</h5>
                        <p>${post.body}</p>
                    </div>
                `).join("");
            })
            .catch(error => console.error("Error fetching data:", error));
    });

    // Form Validation
    contactForm.addEventListener("submit", function(event) {
        event.preventDefault();

        let valid = true;
        document.querySelectorAll(".error").forEach(el => el.textContent = "");

        const name = document.getElementById("name");
        const email = document.getElementById("email");
        const message = document.getElementById("message");

        if (name.value.trim() === "") {
            document.getElementById("nameError").textContent = "Name is required.";
            valid = false;
        }

        if (email.value.trim() === "" || !/\S+@\S+\.\S+/.test(email.value)) {
            document.getElementById("emailError").textContent = "Valid email is required.";
            valid = false;
        }

        if (message.value.trim() === "") {
            document.getElementById("messageError").textContent = "Message cannot be empty.";
            valid = false;
        }

        if (valid) {
            document.getElementById("successMessage").style.display = "block";
            contactForm.reset();
        }
    });
});
