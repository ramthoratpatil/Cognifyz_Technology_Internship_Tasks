// Function to change the background color
function changeBackgroundColor() {
    const colors = ["lightblue", "lightcoral", "lightyellow", "lightpink", "lightgreen"];
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    document.body.style.backgroundColor = randomColor;
}

// Add event listener to the background color button
document.getElementById("changeColorBtn").addEventListener("click", changeBackgroundColor);

// Function to fetch data from JSONPlaceholder
function fetchData() {
    fetch("https://jsonplaceholder.typicode.com/posts?_limit=3") // Fetching 3 articles
        .then(response => response.json()) // Convert response to JSON
        .then(data => {
            const container = document.getElementById("dataContainer");
            container.innerHTML = ""; // Clear previous data

            data.forEach(post => {
                const article = document.createElement("div");
                article.classList.add("article");
                article.innerHTML = `
                    <h3>${post.title}</h3>
                    <p>${post.body}</p>
                `;
                container.appendChild(article);
            });
        })
        .catch(error => console.error("Error fetching data:", error));
}

// Add event listener to the fetch data button
document.getElementById("fetchDataBtn").addEventListener("click", fetchData);

// Form validation function
document.getElementById("contactForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent form submission

    let valid = true;

    // Name validation
    const nameInput = document.getElementById("name");
    const nameError = document.getElementById("nameError");
    if (nameInput.value.trim() === "") {
        nameError.textContent = "Name is required.";
        valid = false;
    } else {
        nameError.textContent = "";
    }

    // Email validation
    const emailInput = document.getElementById("email");
    const emailError = document.getElementById("emailError");
    const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
    if (!emailInput.value.match(emailPattern)) {
        emailError.textContent = "Enter a valid email.";
        valid = false;
    } else {
        emailError.textContent = "";
    }

    // Message validation
    const messageInput = document.getElementById("message");
    const messageError = document.getElementById("messageError");
    if (messageInput.value.trim() === "") {
        messageError.textContent = "Message cannot be empty.";
        valid = false;
    } else {
        messageError.textContent = "";
    }

    // If all inputs are valid, show success message
    if (valid) {
        document.getElementById("successMessage").style.display = "block";
        document.getElementById("contactForm").reset();
    }
});
