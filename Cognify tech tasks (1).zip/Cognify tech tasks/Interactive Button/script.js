// Function to change the background color
function changeBackgroundColor() {
    const colors = ["lightblue", "lightcoral", "lightyellow", "lightpink", "lightgreen"];
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    document.body.style.backgroundColor = randomColor;
}

// Add event listener to the button
document.getElementById("changeColorBtn").addEventListener("click", changeBackgroundColor);
