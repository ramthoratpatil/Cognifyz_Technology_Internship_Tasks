// Function to change the background color
function changeBackgroundColor() {
    const colors = ["lightblue", "lightcoral", "lightyellow", "lightpink", "lightgreen"];
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    document.body.style.backgroundColor = randomColor;
}

// Add event listener to the background color button
document.getElementById("changeColorBtn").addEventListener("click", changeBackgroundColor);

// Function to fetch data from JSONPlaceholder
function fetchData() {
    fetch("https://jsonplaceholder.typicode.com/posts?_limit=3") // Fetching 3 articles
        .then(response => response.json()) // Convert response to JSON
        .then(data => {
            const container = document.getElementById("dataContainer");
            container.innerHTML = ""; // Clear previous data

            data.forEach(post => {
                const article = document.createElement("div");
                article.classList.add("article");
                article.innerHTML = `
                    <h3>${post.title}</h3>
                    <p>${post.body}</p>
                `;
                container.appendChild(article);
            });
        })
        .catch(error => console.error("Error fetching data:", error));
}

// Add event listener to the fetch data button
document.getElementById("fetchDataBtn").addEventListener("click", fetchData);
